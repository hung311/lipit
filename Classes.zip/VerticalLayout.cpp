﻿#include "VerticalLayout.h"

USING_NS_CC;

void VerticalLayout::addChild(Node* child, int zOrder, int tag) {
    Node::addChild(child, zOrder, tag);

    const auto& children = getChildren();

    float totalHeight = 0.0f;
    for (const auto& child : children) {
        totalHeight += child->getContentSize().height;
    }

    float yOffset = -totalHeight / 2.0f;
    for (const auto& child : children) {
        child->setPositionY(yOffset + child->getContentSize().height / 2.0f);
        yOffset += child->getContentSize().height;
    }
}
