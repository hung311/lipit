#ifndef __HORIZONTAL_LAYOUT_H__
#define __HORIZONTAL_LAYOUT_H__

#include "cocos2d.h"

class HorizontalLayout : public cocos2d::Node {
public:
    CREATE_FUNC(HorizontalLayout);

    virtual void addChild(cocos2d::Node* child, int zOrder, int tag) override;
};

#endif // __HORIZONTAL_LAYOUT_H__
