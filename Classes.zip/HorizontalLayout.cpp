﻿#include "HorizontalLayout.h"

USING_NS_CC;

void HorizontalLayout::addChild(Node* child, int zOrder, int tag) {
    Node::addChild(child, zOrder, tag);

    // Lấy danh sách các con
    const auto& children = getChildren();

    // Tính toán tổng kích thước của các con
    float totalWidth = 0.0f;
    for (const auto& child : children) {
        totalWidth += child->getContentSize().width;
    }

    // Đặt vị trí của các con theo chiều ngang
    float xOffset = -totalWidth / 2.0f;
    for (const auto& child : children) {
        child->setPositionX(xOffset + child->getContentSize().width / 2.0f);
        xOffset += child->getContentSize().width;
    }
}
