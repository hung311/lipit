#ifndef __VERTICAL_LAYOUT_H__
#define __VERTICAL_LAYOUT_H__

#include "cocos2d.h"

class VerticalLayout : public cocos2d::Node {
public:
    CREATE_FUNC(VerticalLayout);

    virtual void addChild(cocos2d::Node* child, int zOrder, int tag) override;
};

#endif // __VERTICAL_LAYOUT_H__
